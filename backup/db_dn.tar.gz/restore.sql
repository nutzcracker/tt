--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.12 (Ubuntu 14.12-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.12 (Ubuntu 14.12-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dn_true;
--
-- Name: dn_true; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE dn_true WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'ru_RU.UTF-8';


ALTER DATABASE dn_true OWNER TO postgres;

\connect dn_true

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: dn_true
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO dn_true;

--
-- Name: metrics; Type: TABLE; Schema: public; Owner: dn_true
--

CREATE TABLE public.metrics (
    id integer NOT NULL,
    url character varying NOT NULL,
    date timestamp without time zone NOT NULL,
    "position" double precision NOT NULL,
    ctr double precision NOT NULL,
    impression double precision NOT NULL,
    clicks double precision NOT NULL,
    demand double precision NOT NULL
);


ALTER TABLE public.metrics OWNER TO dn_true;

--
-- Name: metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: dn_true
--

CREATE SEQUENCE public.metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.metrics_id_seq OWNER TO dn_true;

--
-- Name: metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dn_true
--

ALTER SEQUENCE public.metrics_id_seq OWNED BY public.metrics.id;


--
-- Name: metrics_query; Type: TABLE; Schema: public; Owner: dn_true
--

CREATE TABLE public.metrics_query (
    id integer NOT NULL,
    date timestamp without time zone NOT NULL,
    "position" double precision NOT NULL,
    ctr double precision NOT NULL,
    impression double precision NOT NULL,
    demand double precision NOT NULL,
    clicks double precision NOT NULL,
    query character varying NOT NULL
);


ALTER TABLE public.metrics_query OWNER TO dn_true;

--
-- Name: metrics_query_id_seq; Type: SEQUENCE; Schema: public; Owner: dn_true
--

CREATE SEQUENCE public.metrics_query_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.metrics_query_id_seq OWNER TO dn_true;

--
-- Name: metrics_query_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dn_true
--

ALTER SEQUENCE public.metrics_query_id_seq OWNED BY public.metrics_query.id;


--
-- Name: query; Type: TABLE; Schema: public; Owner: dn_true
--

CREATE TABLE public.query (
    query character varying NOT NULL
);


ALTER TABLE public.query OWNER TO dn_true;

--
-- Name: url; Type: TABLE; Schema: public; Owner: dn_true
--

CREATE TABLE public.url (
    url character varying NOT NULL
);


ALTER TABLE public.url OWNER TO dn_true;

--
-- Name: metrics id; Type: DEFAULT; Schema: public; Owner: dn_true
--

ALTER TABLE ONLY public.metrics ALTER COLUMN id SET DEFAULT nextval('public.metrics_id_seq'::regclass);


--
-- Name: metrics_query id; Type: DEFAULT; Schema: public; Owner: dn_true
--

ALTER TABLE ONLY public.metrics_query ALTER COLUMN id SET DEFAULT nextval('public.metrics_query_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: dn_true
--

COPY public.alembic_version (version_num) FROM stdin;
\.
COPY public.alembic_version (version_num) FROM '$$PATH$$/3341.dat';

--
-- Data for Name: metrics; Type: TABLE DATA; Schema: public; Owner: dn_true
--

COPY public.metrics (id, url, date, "position", ctr, impression, clicks, demand) FROM stdin;
\.
COPY public.metrics (id, url, date, "position", ctr, impression, clicks, demand) FROM '$$PATH$$/3343.dat';

--
-- Data for Name: metrics_query; Type: TABLE DATA; Schema: public; Owner: dn_true
--

COPY public.metrics_query (id, date, "position", ctr, impression, demand, clicks, query) FROM stdin;
\.
COPY public.metrics_query (id, date, "position", ctr, impression, demand, clicks, query) FROM '$$PATH$$/3346.dat';

--
-- Data for Name: query; Type: TABLE DATA; Schema: public; Owner: dn_true
--

COPY public.query (query) FROM stdin;
\.
COPY public.query (query) FROM '$$PATH$$/3347.dat';

--
-- Data for Name: url; Type: TABLE DATA; Schema: public; Owner: dn_true
--

COPY public.url (url) FROM stdin;
\.
COPY public.url (url) FROM '$$PATH$$/3344.dat';

--
-- Name: metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dn_true
--

SELECT pg_catalog.setval('public.metrics_id_seq', 2191415, true);


--
-- Name: metrics_query_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dn_true
--

SELECT pg_catalog.setval('public.metrics_query_id_seq', 4349146, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: dn_true
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: metrics metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: dn_true
--

ALTER TABLE ONLY public.metrics
    ADD CONSTRAINT metrics_pkey PRIMARY KEY (id);


--
-- Name: metrics_query metrics_query_pkey; Type: CONSTRAINT; Schema: public; Owner: dn_true
--

ALTER TABLE ONLY public.metrics_query
    ADD CONSTRAINT metrics_query_pkey PRIMARY KEY (id);


--
-- Name: query query_query_key; Type: CONSTRAINT; Schema: public; Owner: dn_true
--

ALTER TABLE ONLY public.query
    ADD CONSTRAINT query_query_key UNIQUE (query);


--
-- Name: url url_pkey; Type: CONSTRAINT; Schema: public; Owner: dn_true
--

ALTER TABLE ONLY public.url
    ADD CONSTRAINT url_pkey PRIMARY KEY (url);


--
-- Name: url url_url_key; Type: CONSTRAINT; Schema: public; Owner: dn_true
--

ALTER TABLE ONLY public.url
    ADD CONSTRAINT url_url_key UNIQUE (url);


--
-- PostgreSQL database dump complete
--

